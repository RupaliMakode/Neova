
	package com.example.demo;

	

	import javax.persistence.EntityManager;
	import javax.persistence.EntityManagerFactory;
	import javax.persistence.EntityTransaction;
	import javax.persistence.Persistence;

	import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.Layer3.AdminRepo;

	@SpringBootTest
	class OnlineShoppingPApplicationTests {

	@Autowired
	AdminRepo repo;
		
	@Test
	void contextLoads() {
	}
	
	

	@Test
	public void insertUser() {
	EntityManagerFactory entityManagerFactory =
	Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here

	System.out.println("Entity Manager Factory : "+entityManagerFactory);

	EntityManager entityManager = entityManagerFactory.createEntityManager();
	//ctrl+shift+M

	System.out.println("Entity Manager : "+entityManager);

	EntityTransaction transaction = entityManager.getTransaction();
	transaction.begin();

	User user = new User(); //transient - in memory
	user.setName("rushabh"); //transient - in memory
	user.setEmail("rushabh@gmail.com");
	user.setPassword("rushabh@123");
	



	entityManager.persist(user);



	transaction.commit();
	}

	//----------------------------------------------------//
	@Test
	public void insertAdmin() {
	EntityManagerFactory entityManagerFactory =
	Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here

	System.out.println("Entity Manager Factory : "+entityManagerFactory);

	EntityManager entityManager = entityManagerFactory.createEntityManager();
	//ctrl+shift+M

	System.out.println("Entity Manager : "+entityManager);

	EntityTransaction transaction = entityManager.getTransaction();
	transaction.begin();
	Admin admin = new Admin(); //new/blank entity object
	admin.setAdminId(10);
	admin.setName("Hrithika");
	admin.setPassword("hrihika123");


	entityManager.persist(admin); //generate the insert query for us
	transaction.commit();

	}

	@Test
	public void insertUserWithWishList() {
	EntityManagerFactory entityManagerFactory =
	Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here

	System.out.println("Entity Manager Factory : "+entityManagerFactory);

	EntityManager entityManager = entityManagerFactory.createEntityManager();
	//ctrl+shift+M

	System.out.println("Entity Manager : "+entityManager);

	EntityTransaction transaction = entityManager.getTransaction();
	transaction.begin();
	User ruser = new User(); //new/blank entity object
	ruser.setName("Lakhan");
	ruser.setEmail("lakhan@gmail.com");
	ruser.setPassword("lakhan123");

	Wishlist wishList = new Wishlist();
	// wishList.setProdId(0);

	ruser.setWishList(wishList); //set the FK
	wishList.setUserId(ruser);//set the FK

	entityManager.persist(ruser);
	entityManager.persist(wishList); //generate the insert query for us



	transaction.commit();

	}

	//-----------------------------//
	@Test
	public void insertRetailer() {
	EntityManagerFactory entityManagerFactory =
	Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here

	System.out.println("Entity Manager Factory : "+entityManagerFactory);

	EntityManager entityManager = entityManagerFactory.createEntityManager();
	//ctrl+shift+M

	System.out.println("Entity Manager : "+entityManager);

	EntityTransaction transaction = entityManager.getTransaction();
	transaction.begin();
	Retailer retailer = new Retailer(); //new/blank entity object

	retailer.setName("Rishi");
	retailer.setMoblienumber(7582125813l);
	retailer.setPassword("rishi123");


	entityManager.persist(retailer); //generate the insert query for us
	transaction.commit();

	}

	@Test
	public void insertRetailerWithAdmin() {
	EntityManagerFactory entityManagerFactory =
	Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here

	System.out.println("Entity Manager Factory : "+entityManagerFactory);

	EntityManager entityManager = entityManagerFactory.createEntityManager();
	//ctrl+shift+M

	System.out.println("Entity Manager : "+entityManager);

	EntityTransaction transaction = entityManager.getTransaction();
	transaction.begin();

	Admin admin = new Admin(); //new/blank entity object

	Retailer retailer = new Retailer();

	retailer.setName("Rishii");
	retailer.setMoblienumber(956140235l);
	retailer.setPassword("rishi123");


	// admin.setWishList(wishList); //set the FK
	retailer.setAdmin(admin);//set the FK

	entityManager.persist(admin);
	entityManager.persist(retailer); //generate the insert query for us



	transaction.commit();

	}

	}

