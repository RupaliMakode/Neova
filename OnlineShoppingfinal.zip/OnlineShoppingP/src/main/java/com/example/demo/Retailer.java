package com.example.demo;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class Retailer {

	@Id
	@GeneratedValue
	@Column(name = "RetailerId")
	private int retailerId;
	
	@Column(name="Name")
	private String name;
	
	  @Column(name="password")
	    private String password;
	    
	  @Column(name="MobliNumber")
	    private long moblienumber;

	  @ManyToOne
	  @JoinColumn(name="adminId")
	  private Admin admin;

	public int getRetailerId() {
		return retailerId;
	}

	public void setRetailerId(int retailerId) {
		this.retailerId = retailerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	

	public long getMoblienumber() {
		return moblienumber;
	}

	public void setMoblienumber(long l) {
		this.moblienumber = l;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	  
	  
}