package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Table;

import org.hibernate.annotations.GeneratorType;
import org.springframework.data.annotation.Id;

@Entity
@Table(name="UserAddress ")
public class UserAddress {
	
	
    @Id
    @GeneratedValue
	private int userAddressId;
    
    
	private String addressline;
	
	private String state;
	
	private String city;
	
	private int postalcode;
	
	
	/*-------  Getters and Setters --------*/
	
	public String getAddressline() {
		return addressline;
	}
	public void setAddressline(String addressline) {
		this.addressline = addressline;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPostalcode() {
		return postalcode;
	}
	public void setPostalcode(int postalcode) {
		this.postalcode = postalcode;
	}
	

}
