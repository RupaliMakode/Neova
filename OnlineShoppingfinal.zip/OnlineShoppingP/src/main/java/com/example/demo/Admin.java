package com.example.demo;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
 
@Entity
public class Admin {

	
	@Id
	@GeneratedValue
	@Column(name = "AdminId")
	private int adminId;
	
	@Column(name="Name")
	private String name;
	
    @Column(name="password")
    private String password;
    
    
    
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "admin")
    private Set<Retailer > retailer;

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<Retailer> getRetailer() {
		return retailer;
	}

	public void setRetailer(Set<Retailer> retailer) {
		this.retailer = retailer;
	}


}
