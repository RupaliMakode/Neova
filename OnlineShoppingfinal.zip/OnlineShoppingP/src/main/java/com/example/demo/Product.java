package com.example.demo;

import java.io.File;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Admin;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.data.annotation.Id;

@Entity
@Table(name="Product")
public class Product {
	
	@Id
	@GeneratedValue
	@Column(name="PRODUCTID")
	private String ProductId;
	
	@JoinColumn(name="RETAILERID") 
	private String RetailerId;
	
	@Column(name="IMAGE") 
	private File img;
	
	@Column(name="PRICE") 
	private float Price;
	
	@Column(name="DESCRIPTION") 
	private String Description;
	
	@Column(name="BRAND") 
	private String Brand;
	
	@Column(name="MODEL") 
	private String Model;
	
	@Column(name="COMPANY")
	private String company;
	
	@ManyToOne
	private User user;
	
	@ManyToOne
	private Admin admin;


	/*-------  Getters and Setters --------*/
	
	public String getRetailerId() {
		return RetailerId;
	}

	public String getProductId() {
		return ProductId;
	}

	public void setProductId(String productId) {
		ProductId = productId;
	}

	public void setRetailerId(String retailerId) {
		RetailerId = retailerId;
	}

	public File getImg() {
		return img;
	}

	public void setImg(File img) {
		this.img = img;
	}

	public float getPrice() {
		return Price;
	}

	public void setPrice(float price) {
		Price = price;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public String getBrand() {
		return Brand;
	}

	public void setBrand(String brand) {
		Brand = brand;
	}

	public String getModel() {
		return Model;
	}

	public void setModel(String model) {
		Model = model;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	
	
	

	
	
}
