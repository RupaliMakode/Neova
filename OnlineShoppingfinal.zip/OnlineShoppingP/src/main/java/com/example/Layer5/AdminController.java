package com.example.Layer5;

import java.util.List;import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Layer3.AdminRepo;
import com.example.Layer3.AdminRepoImpl;
import com.example.demo.Admin;



public class AdminController {

@RestController
@RequestMapping("/admin")
{

	 AdminRepoImpl AdminRepo;
	 @GetMapping("/get/{adminId}") //localhost:8080/dept/get
	 public Admin  getAdmin(@PathVariable("adminId") int x)
	 {
		Admin admin;
		admin= adminRepo.selectAdmin(x);
		 return admin;
		 }
	 @GetMapping("/getAll")  //getAll
	 public List<Admin> getadmins()
	 {
	List<Admin> adminList ;
	adminList = admin.selectAdmins();
	return adminList;
	 }

	 @PostMapping("/add")  //localhost:8080/dept/add
	 public void addAdmin(@RequestBody Admin adminObj) {
		
	adminRepo.insertAdmin(adminObj);
	 }
	 
	 
	 @PutMapping("/update")  //localhost:8080/dept/update
	 public void updateAdmin(@RequestBody Admin adminObj) {
		
	 adminRepo.updateAdmin(adminObj);
	 }
	 
	 
	 @DeleteMapping("/delete/{dno}") //localhost:8080/dept/delete
	 public String getdeleteAdmin(@PathVariable("adminId") int x)
	 {
	Admin admin;
		admin =AdminRepo.selectAdmin(x);
		 return "Deleted Successfully.";
		 }
	 
}


