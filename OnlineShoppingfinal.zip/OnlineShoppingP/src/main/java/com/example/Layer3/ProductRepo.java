package com.example.Layer3;

import java.util.List;

import com.example.demo.Product;



public interface ProductRepo {
	void insertProduct(Product pobj); //C
	
   Product selectProduct(int ProductId); //R
		List<Product> selectProducts(); //RA
		
		void updateproduct(Product pobj); //U
		void deleteProduct(int  ProductId ); //D
		
}
