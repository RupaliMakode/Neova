package com.example.Layer3;

import java.util.List;


import com.example.demo.Admin;


public interface AdminRepo {
void  insertAdmin(Admin admin);
Admin selectAdmin(int adminId);
List<Admin> selectAllAdmin();
void updateAdmin(Admin admin);
void deleteAdmin(int adminId);



}
