package com.example.Layer3;

import java.util.List;

import javax.transaction.Transactional;

import com.example.demo.Admin;





public abstract class AdminRepoImpl extends BaseRepository   implements AdminRepo {
	@Transactional
	public void insertAdmin(Admin aobj) 
	{
		super.persist(aobj); 
		System.out.println("Admin inserted...");
	}

	
	@Override
	public Admin selectAdmin(int adminId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Admin> selectAllAdmin() {
		// TODO Auto-generated method stub
		return null;
	}

	@Transactional 
	public void updateAdmin(Admin aObj) {
		System.out.println(" AdminRepoImpl: Updating admin...");
		super.merge(aObj);
	}

	@Transactional 
	public void deleteAdmin(int adminId)
	{
		System.out.println(" AdminRepoImpl: Deleting Admin");
		super.remove(Admin.class,adminId);
	}

}
