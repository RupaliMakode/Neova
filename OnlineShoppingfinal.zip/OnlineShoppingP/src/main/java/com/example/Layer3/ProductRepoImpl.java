package com.example.Layer3;

import java.util.List;

import javax.transaction.Transactional;


import com.example.demo.Product;

public abstract class ProductRepoImpl extends BaseRepository   implements ProductRepo {
	@Transactional
	public void insertProduct(Product pobj) 
	{
		super.persist(pobj); 
		System.out.println("Product inserted...");
	}

	@Override
	public Product selectProduct(int ProductId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> selectProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Transactional 
	public void updateProduct(Product pObj) {
		System.out.println(" ProductRepoImpl : Updating Product...");
		super.merge(pObj);
	}

	@Transactional 
	public void deleteProduct(int productId)
	{
		System.out.println(" ProductRepoImpl: Deleting Product");
		super.remove(Product.class,productId);
	}

}
