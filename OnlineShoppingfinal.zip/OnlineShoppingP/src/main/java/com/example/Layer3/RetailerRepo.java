package com.example.Layer3;

import java.util.List;

import com.example.demo.Retailer;




public interface RetailerRepo {
void insertRetailer(Retailer robj); //C
	
Retailer selectRetailer(int retailerId); //R
	List<Retailer> selectRetailers(); //RA
	
	void updateRetailer(Retailer eobj); //U
	void deleteRetailer(int retailerId ); //D
	
}

