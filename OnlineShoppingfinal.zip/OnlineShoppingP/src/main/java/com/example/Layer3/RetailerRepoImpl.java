package com.example.Layer3;

import java.util.List;

import javax.transaction.Transactional;

import com.example.demo.Admin;
import com.example.demo.Retailer;

public class RetailerRepoImpl extends BaseRepository implements RetailerRepo {

	@Transactional
	public void insertRetailer(Retailer robj) 
	{
		super.persist(robj); 
		System.out.println("Retailer inserted...");
	}


	@Override
	public Retailer selectRetailer(int eno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Retailer> selectRetailers() {
		// TODO Auto-generated method stub
		return null;
	}
	@Transactional 
	public void updateRetailer(Retailer rObj) {
		System.out.println(" RetailerRepoImpl : Updating REtailer...");
		super.merge(rObj);
	}

	@Transactional 
	public void deleteRetailer(int RetailerId)
	{
		System.out.println(" RetailerRepoImpl: Deleting REtailer");
		super.remove(Retailer.class,RetailerId);
	}

}
