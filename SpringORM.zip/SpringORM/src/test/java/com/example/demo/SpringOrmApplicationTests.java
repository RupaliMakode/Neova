package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Department;
import com.example.demo.layer3.DepartmentRepositoryImpl;

@SpringBootTest
class SpringOrmApplicationTests {

	
	@Autowired
	DepartmentRepositoryImpl deptRepo;
 
 @Test
 void insertDeptTest() {
	 Department dept = new Department();
	 dept.setDepartmentNumber(178);
	 dept.setDepartmentName("Devloper");
	 dept.setDepartmentLocation("Neova");
	 
	 deptRepo.insertDepartment(dept);
 }
}
