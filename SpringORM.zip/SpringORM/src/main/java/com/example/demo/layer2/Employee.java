package com.example.demo.layer2;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="EMP6")
public class Employee
{
	@Id
	@Column(name="EMPNO")
	private int empNumber;
	
	
	@Column(name="ENAME")
	private String empName;
	
	@Column(name="JOB")
	private String job;
	
	@Column(name="MGR")
	private int mgr;
	
	@Column(name="HIREDATE")
	private LocalDate hiredate;
	
	@Column(name="SAL")
	private int salary;
	
	
	@Column(name="COMM")
	private int comm;
	
	@Column(name="DEPTNO")
	private int deptNo;
	
	public int getEmpNumber() {
		return empNumber;
	}
	public void setEmpNumber(int empNumber) {
		this.empNumber = empNumber;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getMgr() {
		return mgr;
	}
	public void setMgr(int mgr) {
		this.mgr = mgr;
	}
	public LocalDate getHiredate() {
		return hiredate;
	}
	public void setHiredate(LocalDate hiredate) {
		this.hiredate = hiredate;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getComm() {
		return comm;
	}
	public void setComm(int comm) {
		this.comm = comm;
	}
	public int getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}
	@Override
	public String toString() {
		return "Employee [empNumber=" + empNumber + ", empName=" + empName + ", job=" + job + ", mgr=" + mgr
				+ ", hiredate=" + hiredate + ", salary=" + salary + ", comm=" + comm + ", deptNo=" + deptNo + "]";
	}
	
}
