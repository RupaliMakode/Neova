package com.java.orm.ORMDEPT;

	import javax.persistence.EntityManager;
	import javax.persistence.EntityManagerFactory;
	import javax.persistence.EntityTransaction;
	import javax.persistence.Persistence;

	public class Testdept {
		public static void main(String[] args) {
						
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA"); //this will read the persistence.xml file
			System.out.println("Got the EntityManagerFactory : "+entityManagerFactory);
			
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			System.out.println("Got the EntityManager :  "+entityManager);
			
			EntityTransaction entityTransaction = entityManager.getTransaction();
			System.out.println("Got the EntityTransaction : "+entityTransaction);
			
			entityTransaction.begin();
					Department deptObj = new Department(); //detached from hibernate
					deptObj.setDepartmentNumber(104);
					deptObj.setDepartmentName("Adam");
					deptObj.setDepartmentLocation("NP"); //till this point it is detached
					
					
					
					entityManager.persist(deptObj); //peristed object now : this will fire the insert query
					
					
			entityTransaction.commit();
			System.out.println("Object is persisted....�");
			
			entityManager.close();
			entityManagerFactory.close();
			System.out.println("Resources closed...");
		}
		
	}


