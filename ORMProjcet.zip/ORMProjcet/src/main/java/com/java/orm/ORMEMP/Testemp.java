package com.java.orm.ORMEMP;

	import javax.persistence.EntityManager;
	import javax.persistence.EntityManagerFactory;
	import javax.persistence.EntityTransaction;
	import javax.persistence.Persistence;

	public class Testemp {
		
		private static Object empObj;

		public static void main(String[] args) {
						
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA"); 
			System.out.println("Got the EntityManagerFactory : "+entityManagerFactory);
			
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			System.out.println("Got the EntityManager :  "+entityManager);
			
			EntityTransaction entityTransaction = entityManager.getTransaction();
			System.out.println("Got the EntityTransaction : "+entityTransaction);
			
			entityTransaction.begin();
				Employee empObj = new Employee (); 
					empObj.setEmployeeNumber(112);
					empObj.setEmployeeName("RAHUL");
					empObj.setEmployeeSalary("25k");
					
					
					
					entityManager.persist(empObj); 
					
					
			entityTransaction.commit();
			System.out.println("Object is persisted....�");
			
			entityManager.close();
			entityManagerFactory.close();
			System.out.println("Resources closed...");
		}

	
		
		
	}


