package com.java.orm.ORMEMP;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class SelectAll {
	@Test
	public void empSelectAllTest() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("entity manager factory : "+entityManagerFactory);
		
		
	Assertions.assertNotNull(entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("entity manager : "+entityManager);
		
	Assertions.assertNotNull(entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		
	Assertions.assertNotNull(transaction);
		
		System.out.println("transaction : "+transaction);
		
		transaction.begin();
		System.out.println("Transaction started....");
		
		System.out.println("null POJO created...");

		Query theQuery = entityManager.createQuery(" from Employee"); 
		
		List<Employee> empList = theQuery.getResultList();
		
	Assertions.assertNotNull(empList);
	Assertions.assertTrue(empList.size() > 0 );
	
		for(Employee emp : empList) {	
			System.out.println("EMPNO : "+emp.getEmployeeNumber());
			System.out.println("EMPNAME  : "+emp.getEmployeeName());
			System.out.println("EMPSALARY   : "+emp.getEmployeeSalary());
			System.out.println("------------");
		}
		System.out.println("RETRIEVED...");
		
		transaction.commit();
		System.out.println("Committed...");
				
		
	}
	
}


