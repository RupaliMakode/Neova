package com.table.Layer2;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product {
  
	private file img;
	private float Price;
	private String RetailerId;
	private String Description;
	private String Brand;
	private String Model;
	public file getImg() {
		return img;
	}
	public void setImg(file img) {
		this.img = img;
	}
	public float getPrice() {
		return Price;
	}
	public void setPrice(float price) {
		Price = price;
	}
	public String getRetailerId() {
		return RetailerId;
	}
	public void setRetailerId(String retailerId) {
		RetailerId = retailerId;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getBrand() {
		return Brand;
	}
	public void setBrand(String brand) {
		Brand = brand;
	}
	public String getModel() {
		return Model;
	}
	public void setModel(String model) {
		Model = model;
	}
	@Override
	public String toString() {
		return "Product [Price=" + Price + ", RetailerId=" + RetailerId + ", Description=" + Description + ", Brand="
				+ Brand + ", Model=" + Model + "]";
	}
	
}
