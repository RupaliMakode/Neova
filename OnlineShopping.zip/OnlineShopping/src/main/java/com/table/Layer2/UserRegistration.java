package com.table.Layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Columns;
import org.springframework.data.annotation.Id;

@Entity
@Table(name="UserRegistration")
public class UserRegistration
{

	@Id
	@Column(name="ID")
	private int UserId;


	@Id
	@Column(name="NAME")
	private  String Name;
	
	@Id
	@Column(name="UMOBLIE NO")
	private long UMoblieNumber;
	
	@Id
	@Column(name="UEMAIL ID")
	private String UEmailId;
	
	@Id
	@Column(name="PWD")
	private int Password;
	
	public int getUserId() {
		return UserId;
	} 
	
	public void setUserId(int userId) {
		UserId = userId;
	}
	
	public String getName() {
		return Name;
	}
	
	public void setName(String name) {
		Name = name;
	}
	public long getMoblieNumber() {
		return UMoblieNumber;
	}
	public void setMoblieNumber(long moblieNumber) {
		UMoblieNumber = moblieNumber;
	}
	public String getEmailId() {
		return UEmailId;
	}
	public void setEmailId(String emailId) {
		UEmailId = emailId;
	}
	public int getPassword() {
		return Password;
	}
	public void setPassword(int password) {
		Password = password;
	}

	@Override
	public String toString() {
		return "UserRegistration [UserId=" + UserId + ", Name=" + Name + ", UMoblieNumber=" + UMoblieNumber
				+ ", UEmailId=" + UEmailId + ", Password=" + Password + "]";
	}
	
	
	
}
