package com.table.Layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.annotation.Id;

@Entity
@Table(name="RetailerRegistration")
public class RetailerRegistration {

	@Id
	@Column(name="RETAILERID") 
	private int RetailerId;
	
	@Id
	@Column(name="RETAILER NAME")
	 private String RetailerName;
	
	@Id
	@Column(name="RMOBLIE NO")
     private long RMoblieNumber;
	
	@Id
	@Column(name="RPWD")
     private String RPassword;
	
	@Id
	@Column(name="RETAILER BRAND")
     private  String RetailerBrand;
	
	@Id
	@Column(name="RETAILER CMPY")
 	 private  String RetailerCompany;
 	
 	
	public int getRetailerId() {
		return RetailerId;
	}
	public void setRetailerId(int retailerId) {
		RetailerId = retailerId;
	}
	public String getRetailerName() {
		return RetailerName;
	}
	public void setRetailerName(String retailerName) {
		RetailerName = retailerName;
	}
	public long getRMoblieNumber() {
		return RMoblieNumber;
	}
	public void setRMoblieNumber(long rMoblieNumber) {
		RMoblieNumber = rMoblieNumber;
	}
	public String getRPassword() {
		return RPassword;
	}
	public void setRPassword(String rPassword) {
		RPassword = rPassword;
	}
	public String getRetailerBrand() {
		return RetailerBrand;
	}
	public void setRetailerBrand(String retailerBrand) {
		RetailerBrand = retailerBrand;
	}
	public String getRetailerCompany() {
		return RetailerCompany;
	}
	public void setRetailerCompany(String retailerCompany) {
		RetailerCompany = retailerCompany;
	}
	@Override
	public String toString() {
		return "RetailerRegistration [RetailerId=" + RetailerId + ", RetailerName=" + RetailerName + ", RMoblieNumber="
				+ RMoblieNumber + ", RPassword=" + RPassword + ", RetailerBrand=" + RetailerBrand + ", RetailerCompany="
				+ RetailerCompany + "]";
	}
	
	
}
